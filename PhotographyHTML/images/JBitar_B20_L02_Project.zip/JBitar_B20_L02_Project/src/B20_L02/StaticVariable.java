package B20_L02;

/**
 * Title:        420-B20 Labs - Winter, 2017
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author Anne Hamilton
 * @version 1.0
 */
public class StaticVariable
{
  private static int staticNum = 0;
  private int num = 0;
  private String name;

  public StaticVariable()
  {
    num++;
    staticNum++;
    name = "Undefined";
  } // StaticVariable()

  public StaticVariable(String n)
  {
    num++;
	staticNum++;
   name = n;
  } // StaticVariable(String)

  public void incrementNumbers()
  {
    num++;
    staticNum++;
  } // incrementNumbers()

  public void setNum(int num)
  {
    this.num = num;
  }

  public int getNum()
  {
    return num;
  }

  public static int getStaticNum()
  {
    return staticNum;	
  }

  public static void setStaticNum(int newStaticNum)
  {
    staticNum = newStaticNum;	
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public String getName()
  {
    return name;
  }
} // StaticVariable class
