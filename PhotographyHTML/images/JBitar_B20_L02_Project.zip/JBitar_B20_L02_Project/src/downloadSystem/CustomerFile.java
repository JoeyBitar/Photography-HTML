package downloadSystem;
import java.io.*;


public class CustomerFile
{

	public static void write(Customer customer) throws IOException
	{
			File custFile = new File("customers.txt");
			FileWriter out = new FileWriter(custFile, true);
	
			out.write(customer.getCustomerNumber() + "~" + customer.getLastName() + "~"
			+ customer.getFirstName() + "~" + customer.getPhoneNumber() + "~"
			+ customer.getNumberDownloads() + "\r\n");
			out.close();
	
			
	}
}
