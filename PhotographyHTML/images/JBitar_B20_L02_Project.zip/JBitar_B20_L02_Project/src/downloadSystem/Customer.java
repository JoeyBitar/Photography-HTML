package downloadSystem;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class Customer
{
	private static int nextCustomerNumber;
  private int customerNumber;
  private String lastName;
  private String firstName;
  private String phoneNumber;
  private int numberDownloads;
 
  public Customer()
  {
  	setCustomerNumber();
    lastName = "Unknown";
    firstName = "Unknown";
    phoneNumber = "9999999999";
    numberDownloads= 0;
  } // Customer()

  public Customer(String first, String last, String phone)
  {
  	setCustomerNumber();
    firstName = first;
    lastName = last;
    phoneNumber = phone;
    numberDownloads= 0;
  } // Customer(String, String, String )

  private void setCustomerNumber(){
  	customerNumber = nextCustomerNumber;
  	++nextCustomerNumber;
  }
  
  public static void initializeNextCustomerNumber() throws Exception 
  {
    Scanner in = new Scanner(System.in);
    //System.out.print ("What is the next customer number?");
   
    
    File customerNumberFile = new File("customerNumber.txt");
    Scanner customerNumberFileScanner = new Scanner(customerNumberFile);
    nextCustomerNumber = customerNumberFileScanner.nextInt();
    in.close();
    
    
    
  } // initializeNextCustomerNumber ()

  public static void rewriteNextCustomerNumber() throws Exception 
  {
	  File customerNumberFile = new File("customerNumber.txt");
	  FileWriter out = new FileWriter(customerNumberFile);
	  out.write(String.valueOf(nextCustomerNumber));
	  out.close();
	  
  }
  
  
  
  public int getCustomerNumber()
  {
    return customerNumber;
  } // getCustomerNumber()

	public void setLastName(String last)
	{
		if (last.length() == 1)
			lastName = last.toUpperCase();
		else
			lastName = Character.toUpperCase(last.charAt(0))
					+ last.substring(1).toLowerCase();
	} // setLastName(String)

	public String getLastName()
	{
		return lastName;
	} // getLastName()

	public void setFirstName(String first)
	{
		if (first.length() == 1)
			firstName = first.toUpperCase();
		else
			firstName = Character.toUpperCase(first.charAt(0))
					+ first.substring(1).toLowerCase();
	} // setFirstName(String first)

	public String getFirstName()
	{
		return firstName;
	} // getFirstName()

	public void setPhoneNumber(String phone)
	{
		phoneNumber = phone;
	} // setPhoneNumber(String)

  public String getPhoneNumber()
  {
    return phoneNumber;
  } // getPhoneNumber()
  
  public double getNumberDownloads()
	{
		return numberDownloads;
	} // getOutstandingBalance()

  public String getFullName()
	{
		return firstName + " " + lastName;
	}

} // Customer
